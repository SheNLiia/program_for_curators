# database.py

# Импорт модуля для работы с SQLite
import sqlite3
# Импорт модуля для работы с операционной системой
import os
# Импорт класса datetime из модуля datetime
from datetime import datetime
# Импорт типов List и Dict для аннотаций типов
from typing import List, Dict


# Определение класса для работы с базой данных справок
class Database:
    # Конструктор класса, принимает путь к базе данных
    def __init__(self, db_path="certificates.db"):
        # Сохранение пути к базе данных в атрибут экземпляра
        self.db_path = db_path
        # Вызов метода проверки существования файла базы данных
        self.check_database_file()

    # Метод проверки существования файла базы данных
    def check_database_file(self):
        # Проверка наличия файла по указанному пути
        if not os.path.exists(self.db_path):
            # Вывод сообщения об ошибке в консоль
            print(f"Ошибка: файл {self.db_path} не найден")
            # Вывод инструкции для пользователя
            print("Сначала создайте базу данных из SQL-файла")
            # Генерация исключения ненайденного файла
            raise FileNotFoundError(f"Файл базы данных {self.db_path} не найден")

    # Метод для подключения к базе данных
    def get_connection(self):
        # Обработка возможных исключений при подключении
        try:
            # Создание подключения к базе данных SQLite
            conn = sqlite3.connect(self.db_path)
            # Установка фабрики строк для возврата результатов в виде словаря
            conn.row_factory = sqlite3.Row
            # Возврат объекта подключения
            return conn
        # Обработка исключения ошибки SQLite
        except sqlite3.Error as e:
            # Вывод сообщения об ошибке в консоль
            print(f"Не удалось подключиться к базе: {e}")
            # Возврат None при неудачном подключении
            return None

    # Метод для получения списка справок с применением фильтров
    def get_certificates_with_filters(self, filters: Dict = None) -> List[Dict]:
        # Получение подключения к базе данных
        conn = self.get_connection()
        # Проверка успешности подключения
        if not conn:
            # Возврат пустого списка при отсутствии подключения
            return []

        # Обработка возможных исключений при выполнении запроса
        try:
            # Запрос для добавления фильтров
            query = "SELECT * FROM v_certificates_details WHERE 1=1"
            # Создание пустого списка для параметров запроса
            params = []

            # Проверка наличия фильтров
            if filters:
                # Вызов метода для добавления условий фильтрации к запросу
                query, params = self.add_filters_to_query(query, params, filters)

            # Добавление сортировки по дате заявки в порядке убывания
            query += " ORDER BY application_date DESC"

            # Создание курсора для выполнения SQL-запросов
            cursor = conn.cursor()
            # Выполнение SQL-запроса с параметрами
            cursor.execute(query, params)
            # Получение всех строк результата запроса
            rows = cursor.fetchall()

            # Создание пустого списка для хранения справок
            certificates = []
            # Итерация по всем строкам результата
            for row in rows:
                # Преобразование строки в словарь с данными справки
                cert = self.row_to_certificate_dict(row)
                # Добавление словаря в список справок
                certificates.append(cert)

            # Закрытие подключения к базе данных
            conn.close()
            # Возврат списка справок
            return certificates

        # Обработка исключения ошибки SQLite
        except sqlite3.Error as e:
            # Вывод сообщения об ошибке в консоль
            print(f"Ошибка в запросе: {e}")
            # Закрытие подключения к базе данных
            conn.close()
            # Возврат пустого списка при ошибке
            return []

    # Метод добавления условий фильтрации в SQL-запрос
    def add_filters_to_query(self, query, params, filters):
        # Проверка наличия фильтра по группе
        if filters.get('group'):
            # Добавление условия фильтрации по названию группы
            query += " AND group_name LIKE ?"
            # Добавление значения параметра с подстановочными символами
            params.append(f"%{filters['group']}%")

        # Проверка наличия фильтра по специальности
        if filters.get('major') and filters['major'] != "Все":
            # Добавление условия фильтрации по специальности с кодом
            query += " AND major_with_code LIKE ?"
            # Добавление значения параметра с подстановочными символами
            params.append(f"%{filters['major']}%")

        # Проверка наличия фильтра по дате начала
        if filters.get('date_from'):
            # Добавление условия фильтрации по дате заявки (больше или равно)
            query += " AND application_date >= ?"
            # Добавление значения параметра даты начала
            params.append(filters['date_from'])

        # Проверка наличия фильтра по дате окончания
        if filters.get('date_to'):
            # Добавление условия фильтрации по дате заявки (меньше или равно)
            query += " AND application_date <= ?"
            # Добавление значения параметра даты окончания
            params.append(filters['date_to'])

        # Проверка наличия фильтра по ФИО студента
        if filters.get('fio'):
            # Добавление условия фильтрации по полному имени студента
            query += " AND student_full_name LIKE ?"
            # Добавление значения параметра с подстановочными символами
            params.append(f"%{filters['fio']}%")

        # Возврат модифицированного запроса и списка параметров
        return query, params

    # Метод преобразования строки результата запроса в словарь
    def row_to_certificate_dict(self, row):
        # Форматирование даты создания записи
        created_at = self.format_date(row['created_at'])

        # Форматирование периода отсутствия
        period_display = self.format_period(row['absence_start'], row['absence_end'])

        # Определение отображения информации о родителе
        parent_display = self.get_parent_display(row['parent_full_name'], row['student_full_name'])

        # Создание словаря с данными справки
        certificate = {
            'certificate_id': row['certificate_id'],
            'student': row['student_full_name'].strip(),
            'major': row['major_with_code'],
            'group': row['group_name'],
            'created_at': created_at,
            'parent': parent_display,
            'period': period_display,
            'status': row['status'],
            'status_db': row['status'],
            'has_file': bool(row['file_url']),
            'parent_full_name': row['parent_full_name']
        }

        # Возврат словаря с данными справки
        return certificate

    # Метод форматирования периода отсутствия
    def format_period(self, start_date, end_date):
        # Проверка наличия обеих дат
        if not start_date or not end_date:
            # Возврат пустой строки при отсутствии дат
            return ""

        # Форматирование даты начала без времени
        start = self.format_date(start_date, with_time=False)
        # Форматирование даты окончания без времени
        end = self.format_date(end_date, with_time=False)
        # Возврат отформатированного периода
        return f"{start} - {end}"

    # Метод определения отображения информации о родителе
    def get_parent_display(self, parent_name, student_name):
        # Удаление лишних пробелов в имени студента
        student_name = student_name.strip()

        # Проверка наличия имени родителя
        if not parent_name:
            # Возврат пустой строки при отсутствии имени родителя
            return ""

        # Удаление лишних пробелов в имени родителя
        parent_name = parent_name.strip()

        # Сравнение имен родителя и студента
        if parent_name == student_name:
            # Возврат пустой строки при совпадении имен
            return ""

        # Возврат имени родителя при различии имен
        return parent_name

    # Метод удаления справки по идентификатору
    def delete_certificate(self, certificate_id):
        # Получение подключения к базе данных
        conn = self.get_connection()
        # Проверка успешности подключения
        if not conn:
            # Возврат False при отсутствии подключения
            return False

        # Обработка возможных исключений при удалении
        try:
            # Создание курсора для выполнения SQL-запросов
            cursor = conn.cursor()

            # Удаление связанных файлов справки
            cursor.execute("DELETE FROM certificate_files WHERE certificate_id = ?", (certificate_id,))

            # Удаление записи о справке
            cursor.execute("DELETE FROM certificates WHERE certificate_id = ?", (certificate_id,))

            # Фиксация изменений в базе данных
            conn.commit()

            # Проверка количества затронутых строк
            success = cursor.rowcount > 0
            # Закрытие подключения к базе данных
            conn.close()

            # Возврат результата операции удаления
            return success

        # Обработка общего исключения
        except Exception as e:
            # Вывод сообщения об ошибке в консоль
            print("Ошибка при удалении:", e)
            # Закрытие подключения к базе данных
            conn.close()
            # Возврат False при ошибке
            return False

    # Метод получения списка всех специальностей
    def get_all_majors(self) -> List[str]:
        # Получение подключения к базе данных
        conn = self.get_connection()
        # Проверка успешности подключения
        if not conn:
            # Возврат списка с единственным элементом "Все" при отсутствии подключения
            return ["Все"]

        # Обработка возможных исключений при выполнении запроса
        try:
            # Создание курсора для выполнения SQL-запросов
            cursor = conn.cursor()
            # Выполнение запроса на получение специальностей в формате "Название (код)"
            cursor.execute("SELECT major_name || ' (' || major_code || ')' FROM majors ORDER BY major_name")

            # Создание списка специальностей из результатов запроса
            majors_list = [row[0] for row in cursor.fetchall()]
            # Закрытие подключения к базе данных
            conn.close()

            # Добавление элемента "Все" в начало списка
            return ["Все"] + majors_list

        # Обработка исключения ошибки SQLite
        except sqlite3.Error as e:
            # Вывод сообщения об ошибке в консоль
            print(f"Ошибка при загрузке специальностей: {e}")
            # Закрытие подключения к базе данных
            conn.close()
            # Возврат списка с единственным элементом "Все" при ошибке
            return ["Все"]

    # Метод простого форматирования даты
    def format_date(self, date_string, with_time=True):
        # Проверка наличия строки с датой
        if not date_string:
            # Возврат пустой строки при отсутствии даты
            return ""

        # Обработка возможных исключений при форматировании
        try:
            # Определение списка возможных форматов даты
            date_formats = [
                '%Y-%m-%d %H:%M:%S',  # Формат с временем
                '%Y-%m-%d'  # Формат без времени
            ]

            # Перебор форматов даты
            for date_format in date_formats:
                # Попытка разобрать строку с датой
                try:
                    # Преобразование строки в объект datetime
                    dt = datetime.strptime(str(date_string), date_format)
                    # Проверка необходимости включения времени в результат
                    if with_time and date_format == '%Y-%m-%d %H:%M:%S':
                        # Форматирование даты с временем
                        return dt.strftime('%d.%m.%Y %H:%M')
                    else:
                        # Форматирование даты без времени
                        return dt.strftime('%d.%m.%Y')
                # Продолжение перебора при ошибке разбора
                except:
                    continue

            # Возврат исходной строки при невозможности разбора
            return str(date_string)

        # Возврат исходной строки при общем исключении
        except:
            return str(date_string)

    # Метод получения подробной информации о справке
    def get_certificate_details(self, certificate_id: int) -> Dict:
        # Получение подключения к базе данных
        conn = self.get_connection()
        # Проверка успешности подключения
        if not conn:
            # Возврат пустого словаря при отсутствии подключения
            return {}

        # Обработка возможных исключений при выполнении запроса
        try:
            # Создание курсора для выполнения SQL-запросов
            cursor = conn.cursor()
            # Выполнение запроса на получение деталей справки по идентификатору
            cursor.execute("SELECT * FROM v_certificates_details WHERE certificate_id = ?", (certificate_id,))
            # Получение одной строки результата
            row = cursor.fetchone()

            # Проверка наличия результата
            if not row:
                # Закрытие подключения к базе данных
                conn.close()
                # Возврат пустого словаря при отсутствии справки
                return {}

            # Форматирование даты создания с временем
            created_at = self.format_date(row['created_at'], with_time=True)
            # Форматирование даты начала отсутствия без времени
            absence_start = self.format_date(row['absence_start'], with_time=False)
            # Форматирование даты окончания отсутствия без времени
            absence_end = self.format_date(row['absence_end'], with_time=False)

            # Определение отображения информации о родителе для детального просмотра
            parent_display = self.get_parent_display_for_details(row['parent_full_name'], row['student_full_name'])

            # Создание словаря с детальной информацией о справке
            certificate = {
                'certificate_id': row['certificate_id'],
                'student': row['student_full_name'].strip(),
                'group': row['group_name'],
                'major': row['major_with_code'],
                'application_date': self.format_date(row['application_date'], with_time=False),
                'absence_start': absence_start,
                'absence_end': absence_end,
                'created_at': created_at,
                'status': row['status'],
                'status_db': row['status'],
                'parent': parent_display,
                'parent_full_name': row['parent_full_name'],
                'parent_phone': row['parent_phone'],
                'parent_email': row['parent_email'],
                'file_url': row['file_url'],
                'file_name': row['file_name']
            }

            # Закрытие подключения к базе данных
            conn.close()
            # Возврат словаря с детальной информацией
            return certificate

        # Обработка исключения ошибки SQLite
        except sqlite3.Error as e:
            # Вывод сообщения об ошибке в консоль
            print(f"Ошибка при загрузке справки: {e}")
            # Закрытие подключения к базе данных
            conn.close()
            # Возврат пустого словаря при ошибке
            return {}

    # Метод определения отображения информации о родителе для детального просмотра
    def get_parent_display_for_details(self, parent_name, student_name):
        # Удаление лишних пробелов в имени студента
        student_name = student_name.strip()

        # Проверка наличия имени родителя
        if not parent_name:
            # Возврат пустой строки при отсутствии имени родителя
            return ""

        # Удаление лишних пробелов в имени родителя
        parent_name = parent_name.strip()

        # Сравнение имен родителя и студента
        if parent_name == student_name:
            # Возврат строки "(студент)" при совпадении имен
            return "(студент)"

        # Возврат имени родителя при различии имен
        return parent_name

    # Метод изменения статуса справки
    def update_certificate_status(self, certificate_id: int, status: str) -> bool:
        # Получение подключения к базе данных
        conn = self.get_connection()
        # Проверка успешности подключения
        if not conn:
            # Возврат False при отсутствии подключения
            return False

        # Обработка возможных исключений при обновлении
        try:
            # Создание курсора для выполнения SQL-запросов
            cursor = conn.cursor()
            # Выполнение запроса на обновление статуса справки
            cursor.execute("UPDATE certificates SET status = ? WHERE certificate_id = ?", (status, certificate_id))

            # Фиксация изменений в базе данных
            conn.commit()
            # Закрытие подключения к базе данных
            conn.close()

            # Проверка количества затронутых строк и возврат результата
            return cursor.rowcount > 0

        # Обработка исключения ошибки SQLite
        except sqlite3.Error as e:
            # Вывод сообщения об ошибке в консоль
            print(f"Ошибка при смене статуса: {e}")
            # Закрытие подключения к базе данных
            conn.close()
            # Возврат False при ошибке
            return False

    # Метод отметки всех справок как просмотренных
    def mark_all_as_viewed(self) -> bool:
        # Получение подключения к базе данных
        conn = self.get_connection()
        # Проверка успешности подключения
        if not conn:
            # Возврат False при отсутствии подключения
            return False

        # Обработка возможных исключений при массовом обновлении
        try:
            # Создание курсора для выполнения SQL-запросов
            cursor = conn.cursor()
            # Выполнение запроса на обновление статуса всех непросмотренных справок
            cursor.execute("UPDATE certificates SET status = 'Просмотрено' WHERE status = 'Не просмотрено'")

            # Фиксация изменений в базе данных
            conn.commit()
            # Закрытие подключения к базе данных
            conn.close()

            # Проверка количества затронутых строк и возврат результата
            return cursor.rowcount > 0

        # Обработка исключения ошибки SQLite
        except sqlite3.Error as e:
            # Вывод сообщения об ошибке в консоль
            print(f"Ошибка при массовом обновлении: {e}")
            # Закрытие подключения к базе данных
            conn.close()
            # Возврат False при ошибке
            return False

    # Метод экспорта всех данных
    def export_all_data(self) -> List[Dict]:
        # Возврат всех справок с помощью метода get_certificates_with_filters
        return self.get_certificates_with_filters()
