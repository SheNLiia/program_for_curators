# yandex_import.py

# Импорт модуля для выполнения HTTP-запросов
import requests
# Импорт библиотеки pandas для работы с данными
import pandas as pd
# Импорт модуля для работы с SQLite
import sqlite3
# Импорт класса datetime
from datetime import datetime
# Импорт модуля для работы с JSON
import json
# Импорт модуля для работы с операционной системой
import os

# Загрузка переменных окружения из файла .env
from dotenv import load_dotenv

# Вызов функции загрузки переменных окружения
load_dotenv()


# Определение класса для импорта данных из Яндекс.Форм
class YandexFormsImporter:
    # Конструктор класса, принимает путь к файлу базы данных
    def __init__(self, db_file=None):
        # Загрузка URL публичного API форм из переменной окружения со значением по умолчанию
        self.api_url = os.getenv('FORMS_PUBLIC_API', 'https://api.forms.yandex.net/v1')
        # Загрузка OAuth токена из переменной окружения
        self.token = os.getenv('FORMS_OAUTH_TOKEN')
        # Загрузка идентификатора опроса из переменной окружения
        self.form_id = os.getenv('SURVEY_ID')
        # Установка пути к файлу базы данных
        self.db_file = db_file or os.getenv('DB_FILE', 'certificates.db')

        # Вызов метода проверки настроек
        self._check_settings()

    # Метод проверки необходимых настроек
    def _check_settings(self):
        # Создание пустого списка для хранения проблем
        problems = []

        # Проверка наличия токена
        if not self.token:
            # Добавление названия параметра в список проблем
            problems.append('FORMS_OAUTH_TOKEN')
        # Проверка наличия идентификатора формы
        if not self.form_id:
            # Добавление названия параметра в список проблем
            problems.append('SURVEY_ID')

        # Проверка наличия проблем
        if problems:
            # Формирование сообщения об ошибке
            error_msg = f"Ошибка: не указаны {', '.join(problems)} в файле .env"
            # Генерация исключения ValueError
            raise ValueError(error_msg)

        # Вывод информационного сообщения о загрузке настроек
        print("✅ Все настройки загружены:")
        # Вывод идентификатора формы
        print(f"   Форма: {self.form_id}")
        # Вывод пути к файлу базы данных
        print(f"   База данных: {self.db_file}")
        # Вывод последних 4 символов токена (для безопасности)
        print(f"   Токен: ***{self.token[-4:] if self.token else ''}")

    # Статический метод разделения ФИО на компоненты
    @staticmethod
    def split_fio(full_name):
        # Проверка наличия полного имени
        if not full_name or pd.isna(full_name):
            # Возврат пустых строк при отсутствии имени
            return "", "", ""

        # Разделение строки на части по пробелам
        parts = str(full_name).strip().split()

        # Проверка количества частей
        if len(parts) >= 3:
            # Возврат фамилии, имени и отчества
            return parts[0], parts[1], " ".join(parts[2:])
        elif len(parts) == 2:
            # Возврат фамилии и имени (отчество пустое)
            return parts[0], parts[1], ""
        elif len(parts) == 1:
            # Возврат только фамилии
            return parts[0], "", ""
        else:
            # Возврат пустых строк
            return "", "", ""

    # Статический метод безопасного преобразования JSON
    @staticmethod
    def safe_parse_json(text):
        # Проверка типа входных данных
        if not isinstance(text, str):
            # Возврат исходных данных, если не строка
            return text

        # Попытка разбора JSON
        try:
            # Преобразование строки в объект JSON
            return json.loads(text)
        # Продолжение при ошибке разбора JSON
        except:
            pass

        # Возврат исходной строки при невозможности разбора
        return text

    # Статический метод разделения дат
    @staticmethod
    def split_dates(date_text):
        # Проверка наличия текста с датами
        if pd.isna(date_text) or not date_text:
            # Возврат None для обеих дат при отсутствии текста
            return None, None

        # Проверка, является ли текст строкой в квадратных скобках
        if isinstance(date_text, str) and date_text.startswith('[') and date_text.endswith(']'):
            # Очистка текста от скобок и кавычек
            clean_text = date_text[1:-1].replace("'", "").replace('"', "")
            # Разделение текста по запятым
            dates = [d.strip() for d in clean_text.split(',')]

            # Проверка количества найденных дат
            if len(dates) >= 2:
                # Возврат начала и конца периода
                return dates[0], dates[1]
            elif len(dates) == 1:
                # Возврат одной даты для начала и конца
                return dates[0], dates[0]

        # Проверка, является ли текст списком
        elif isinstance(date_text, list):
            # Проверка количества элементов в списке
            if len(date_text) >= 2:
                # Возврат начала и конца периода
                return str(date_text[0]), str(date_text[1])
            elif len(date_text) == 1:
                # Возврат одной даты для начала и конца
                return str(date_text[0]), str(date_text[0])

        # Возврат None для обеих дат по умолчанию
        return None, None

    # Метод получения ответов из Яндекс.Форм
    def get_responses(self, limit=200):
        # Вывод сообщения о начале запроса данных
        print("Запрашиваем данные из Яндекс.Форм...")

        # Формирование URL для запроса ответов
        url = f'{self.api_url}/surveys/{self.form_id}/answers'
        # Установка заголовков запроса с токеном авторизации
        headers = {'Authorization': f'OAuth {self.token}'}

        # Установка параметров запроса
        params = {'limit': limit, 'include': ['system']}

        # Обработка возможных исключений при запросе
        try:
            # Выполнение GET-запроса с таймаутом 30 секунд
            response = requests.get(url, headers=headers, params=params, timeout=30)

            # Проверка статуса ответа
            if response.status_code != 200:
                # Вывод сообщения об ошибке
                print(f"Ошибка: сервер вернул код {response.status_code}")
                # Возврат None при ошибке
                return None, None

            # Преобразование ответа в JSON
            data = response.json()
            # Извлечение списка ответов
            answers = data.get('answers', [])
            # Извлечение информации о колонках
            columns = data.get('columns', [])

            # Проверка наличия ответов
            if not answers:
                # Вывод сообщения об отсутствии ответов
                print("В форме нет ответов")
                # Возврат пустого списка и информации о колонках
                return [], columns

            # Создание пустого списка для обработанных ответов
            processed_answers = []

            # Итерация по всем ответам
            for answer in answers:
                # Создание пустого словаря для данных строки
                row_data = {}

                # Извлечение идентификатора ответа
                row_data['ID'] = answer.get('id')

                # Извлечение времени создания
                created_time = answer.get('created')
                # Сохранение времени создания в словарь
                row_data['created'] = created_time

                # Проверка наличия времени создания
                if created_time:
                    # Обработка возможных исключений при преобразовании времени
                    try:
                        # Преобразование строки времени в объект datetime
                        dt = datetime.fromisoformat(created_time.replace('Z', '+00:00'))
                        # Добавление 3 часов для московского времени
                        dt = dt.replace(hour=dt.hour + 3)
                        # Форматирование времени и сохранение в словарь
                        row_data['Время создания'] = dt.strftime('%Y-%m-%d %H:%M:%S')
                    # Сохранение исходного времени при ошибке преобразования
                    except:
                        row_data['Время создания'] = created_time

                # Извлечение данных ответа
                answer_data = answer.get('data', [])

                # Итерация по элементам данных ответа
                for i, item in enumerate(answer_data):
                    # Формирование имени колонки по умолчанию
                    column_name = f'col_{i}'

                    # Проверка наличия информации о колонке
                    if i < len(columns):
                        # Получение информации о колонке
                        column_info = columns[i]
                        # Извлечение текстового названия колонки
                        column_name = column_info.get('text', f'col_{i}')

                    # Преобразование значения в текст
                    if item is None:
                        # Установка пустой строки для None
                        value = ''
                    elif isinstance(item, dict):
                        # Проверка наличия ключа 'value'
                        if 'value' in item:
                            # Извлечение значения
                            value = str(item.get('value', ''))
                        # Проверка наличия ключа 'values'
                        elif 'values' in item:
                            # Извлечение списка значений
                            values = item.get('values', [])
                            # Использование первого значения, если список не пуст
                            value = str(values[0]) if values else ''
                        else:
                            # Преобразование словаря в JSON строку
                            value = json.dumps(item, ensure_ascii=False)
                    elif isinstance(item, list):
                        # Преобразование списка в строку
                        value = str(item)
                    else:
                        # Преобразование любого другого типа в строку
                        value = str(item)

                    # Сохранение значения в словарь с ключом имени колонки
                    row_data[column_name] = value

                # Добавление обработанной строки в список
                processed_answers.append(row_data)

            # Вывод количества полученных ответов
            print(f"Получено ответов: {len(processed_answers)}")
            # Возврат обработанных ответов и информации о колонках
            return processed_answers, columns

        # Обработка общего исключения
        except Exception as e:
            # Вывод сообщения об ошибке
            print(f"Ошибка при запросе: {e}")
            # Возврат None при ошибке
            return None, None

    # Метод сохранения данных в Excel файл
    def save_to_excel(self, data, columns_info):
        # Проверка наличия данных
        if not data:
            # Вывод сообщения об отсутствии данных
            print("Нет данных для сохранения")
            # Возврат None
            return None

        # Создание DataFrame из данных
        df = pd.DataFrame(data)

        # Определение порядка колонок
        columns_order = ['ID', 'Время создания']
        # Добавление остальных колонок в конец списка порядка
        for col in df.columns:
            if col not in columns_order:
                columns_order.append(col)

        # Переупорядочивание DataFrame по заданному порядку колонок
        df = df[columns_order]

        # Формирование имени файла
        filename = f"{self.form_id}_answers.xlsx"
        # Сохранение DataFrame в Excel файл без индекса
        df.to_excel(filename, index=False)

        # Вывод сообщения о сохранении файла
        print(f"Файл сохранен: {filename}")
        # Возврат имени сохраненного файла
        return filename

    # Метод импорта данных в базу данных
    def import_to_database(self, df):
        # Вывод сообщения о начале импорта
        print("Начинаем импорт в базу данных...")

        # Попытка подключения к базе данных
        try:
            # Создание подключения к SQLite базе данных
            conn = sqlite3.connect(self.db_file)
            # Создание курсора для выполнения SQL-запросов
            cursor = conn.cursor()
        # Обработка исключения при подключении
        except Exception as e:
            # Возврат False и сообщения об ошибке
            return False, f"Не могу подключиться к базе: {e}"

        # Инициализация счетчиков импортированных и пропущенных записей
        imported = 0
        skipped = 0

        # Обработка возможных исключений при импорте
        try:
            # Итерация по строкам DataFrame
            for index, row in df.iterrows():
                # Получение ФИО студента из разных возможных колонок
                student_name = row.get("Укажите ФИО студента") or row.get("Укажите ФИО студента (пример)")

                # Проверка наличия имени студента
                if not student_name or pd.isna(student_name):
                    # Пропуск записи при отсутствии имени
                    continue

                # Разделение ФИО студента на компоненты
                last_name, first_name, middle_name = self.split_fio(student_name)

                # Получение группы студента
                group = str(row.get("Группа студента (пример: 403ИС-22)", "")).strip()
                # Установка значения по умолчанию для группы
                if not group:
                    group = "000-00"

                # Проверка существования группы в базе данных
                cursor.execute("SELECT group_id FROM groups WHERE group_name=?", (group,))
                # Получение результата запроса
                result = cursor.fetchone()

                # Проверка наличия группы
                if result:
                    # Использование существующего идентификатора группы
                    group_id = result[0]
                else:
                    # Получение первого идентификатора специальности
                    cursor.execute("SELECT major_id FROM majors LIMIT 1")
                    major_id = cursor.fetchone()[0]
                    # Создание новой группы
                    cursor.execute("INSERT INTO groups (group_name, major_id) VALUES (?,?)", (group, major_id))
                    # Получение идентификатора новой группы
                    group_id = cursor.lastrowid

                # Проверка существования студента в базе данных
                cursor.execute(
                    """SELECT student_id
                       FROM students
                       WHERE last_name = ?
                         AND first_name = ?
                         AND group_id = ?""",
                    (last_name or "", first_name or "", group_id)
                )
                # Получение результата запроса
                result = cursor.fetchone()

                # Проверка наличия студента
                if result:
                    # Использование существующего идентификатора студента
                    student_id = result[0]
                else:
                    # Создание нового студента
                    cursor.execute(
                        "INSERT INTO students (last_name, first_name, middle_name, group_id) VALUES (?,?,?,?)",
                        (last_name, first_name, middle_name, group_id)
                    )
                    # Получение идентификатора нового студента
                    student_id = cursor.lastrowid

                # Установка даты заявки по умолчанию (текущая дата)
                application_date = datetime.now().date()
                # Инициализация переменной времени создания
                created_at = None

                # Проверка наличия колонки 'Время создания'
                if 'Время создания' in df.columns and not pd.isna(row.get('Время создания')):
                    # Попытка преобразования времени создания
                    try:
                        dt = pd.to_datetime(row['Время создания'])
                        # Извлечение даты из datetime
                        application_date = dt.date()
                        # Форматирование datetime в строку
                        created_at = dt.strftime('%Y-%m-%d %H:%M:%S')
                    # Продолжение при ошибке преобразования
                    except:
                        pass

                # Проверка наличия колонки 'created'
                elif 'created' in df.columns and not pd.isna(row.get('created')):
                    # Попытка преобразования времени создания из ISO формата
                    try:
                        dt = datetime.fromisoformat(str(row['created']).replace('Z', '+00:00'))
                        # Добавление 3 часов для московского времени
                        dt = dt.replace(hour=dt.hour + 3)
                        # Извлечение даты из datetime
                        application_date = dt.date()
                        # Форматирование datetime в строку
                        created_at = dt.strftime('%Y-%m-%d %H:%M:%S')
                    # Продолжение при ошибке преобразования
                    except:
                        pass

                # Проверка дубликатов по времени создания
                if created_at:
                    cursor.execute(
                        "SELECT certificate_id FROM certificates WHERE student_id=? AND created_at=?",
                        (student_id, created_at)
                    )
                    # Пропуск записи при обнаружении дубликата
                    if cursor.fetchone():
                        skipped += 1
                        continue

                # Получение ФИО заявителя (родителя)
                parent_name = row.get("Укажите ФИО заявителя")

                # Проверка наличия имени заявителя
                if not parent_name or pd.isna(parent_name):
                    # Использование данных студента при отсутствии заявителя
                    parent_last, parent_first, parent_middle = last_name, first_name, middle_name
                else:
                    # Разделение ФИО заявителя на компоненты
                    parent_last, parent_first, parent_middle = self.split_fio(parent_name)

                # Проверка существования заявителя в базе данных
                cursor.execute(
                    """SELECT parent_id
                       FROM parents
                       WHERE student_id = ?
                         AND last_name = ?
                         AND first_name = ?""",
                    (student_id, parent_last or "", parent_first or "")
                )
                # Получение результата запроса
                result = cursor.fetchone()

                # Проверка наличия заявителя
                if result:
                    # Использование существующего идентификатора заявителя
                    parent_id = result[0]
                else:
                    # Создание нового заявителя
                    cursor.execute(
                        "INSERT INTO parents (student_id, last_name, first_name, middle_name) VALUES (?,?,?,?)",
                        (student_id, parent_last, parent_first, parent_middle)
                    )
                    # Получение идентификатора нового заявителя
                    parent_id = cursor.lastrowid

                # Получение периода отсутствия
                period = row.get("Укажите период отсутствия")
                # Инициализация переменных дат начала и окончания
                start_date = None
                end_date = None

                # Проверка наличия периода
                if pd.isna(period) or not period:
                    # Поиск отдельных колонок с датами
                    for col in df.columns:
                        col_lower = str(col).lower()
                        # Поиск колонки с началом периода
                        if 'начало' in col_lower and not pd.isna(row.get(col)):
                            # Попытка преобразования даты начала
                            try:
                                start_date = pd.to_datetime(row[col]).date()
                            # Продолжение при ошибке преобразования
                            except:
                                pass
                        # Поиск колонки с окончанием периода
                        elif 'конец' in col_lower and not pd.isna(row.get(col)):
                            # Попытка преобразования даты окончания
                            try:
                                end_date = pd.to_datetime(row[col]).date()
                            # Продолжение при ошибке преобразования
                            except:
                                pass
                else:
                    # Разделение диапазона дат
                    start_str, end_str = self.split_dates(period)
                    # Проверка наличия даты начала
                    if start_str:
                        # Попытка преобразования дат
                        try:
                            start_date = pd.to_datetime(start_str).date()
                            # Проверка наличия даты окончания
                            if end_str:
                                end_date = pd.to_datetime(end_str).date()
                            else:
                                # Использование даты начала как даты окончания
                                end_date = start_date
                        # Продолжение при ошибке преобразования
                        except:
                            pass

                # Установка текущей даты как даты начала при отсутствии
                if not start_date:
                    start_date = datetime.now().date()
                # Установка даты начала как даты окончания при отсутствии
                if not end_date:
                    end_date = start_date

                # Создание записи о справке с временем создания
                if created_at:
                    cursor.execute(
                        """INSERT INTO certificates
                           (student_id, application_date, parent_id, absence_start, absence_end, status, created_at)
                           VALUES (?, ?, ?, ?, ?, ?, ?)""",
                        (student_id, application_date, parent_id, start_date, end_date, "Не просмотрено", created_at)
                    )
                else:
                    # Проверка дубликатов по дате заявки
                    cursor.execute(
                        "SELECT certificate_id FROM certificates WHERE student_id=? AND application_date=?",
                        (student_id, application_date)
                    )
                    # Пропуск записи при обнаружении дубликата
                    if cursor.fetchone():
                        skipped += 1
                        continue

                    # Создание записи о справке без времени создания
                    cursor.execute(
                        """INSERT INTO certificates
                           (student_id, application_date, parent_id, absence_start, absence_end, status)
                           VALUES (?, ?, ?, ?, ?, ?)""",
                        (student_id, application_date, parent_id, start_date, end_date, "Не просмотрено")
                    )

                # Получение идентификатора созданной справки
                cert_id = cursor.lastrowid

                # Обработка прикрепленного файла
                file_info = row.get("Файл")
                # Проверка наличия информации о файле
                if file_info and not pd.isna(file_info):
                    # Безопасное преобразование информации о файле
                    file_data = self.safe_parse_json(str(file_info))

                    # Проверка типа данных файла
                    if isinstance(file_data, dict):
                        # Извлечение URL файла из словаря
                        file_url = file_data.get('path') or ''
                        # Извлечение имени файла из словаря
                        file_name = file_data.get('name') or file_data.get('file_name') or ''
                    else:
                        # Использование строки как URL файла
                        file_url = str(file_data)
                        # Извлечение имени файла из URL
                        file_name = file_url.split('/')[-1].split('?')[0] if '/' in file_url else file_url

                    # Проверка наличия URL файла
                    if file_url:
                        # Создание записи о файле справки
                        cursor.execute(
                            "INSERT INTO certificate_files (certificate_id, file_url, file_name) VALUES (?,?,?)",
                            (cert_id, file_url, file_name)
                        )

                # Увеличение счетчика импортированных записей
                imported += 1

                # Вывод прогресса каждые 20 записей
                if (imported + skipped) % 20 == 0:
                    print(f"Обработано: {imported + skipped}, Импортировано: {imported}, Пропущено: {skipped}")

            # Фиксация изменений в базе данных
            conn.commit()
            # Закрытие подключения к базе данных
            conn.close()

            # Возврат успешного результата с количеством импортированных и пропущенных записей
            return True, f"Успешно: импортировано {imported}, пропущено {skipped}"

        # Обработка общего исключения при импорте
        except Exception as e:
            # Закрытие подключения к базе данных
            conn.close()
            # Возврат False и сообщения об ошибке
            return False, f"Ошибка: {e}"

    # Метод импорта данных из Excel файла
    def import_excel_file(self, excel_file):
        # Обработка возможных исключений при чтении Excel
        try:
            # Чтение данных из Excel файла в DataFrame
            df = pd.read_excel(excel_file)
            # Вызов метода импорта в базу данных
            return self.import_to_database(df)
        # Обработка общего исключения
        except Exception as e:
            # Возврат False и сообщения об ошибке
            return False, f"Ошибка чтения Excel: {e}"

    # Основной метод для запуска импорта
    def run_import(self, save_excel=False):
        # Получение ответов из Яндекс.Форм
        data, columns = self.get_responses()

        # Проверка успешности получения данных
        if data is None:
            # Возврат False и сообщения об ошибке
            return False, "Не удалось получить данные"

        # Создание DataFrame из полученных данных
        df = pd.DataFrame(data)

        # Проверка наличия данных в DataFrame
        if df.empty:
            # Возврат False и сообщения об отсутствии данных
            return False, "Нет данных для импорта"

        # Проверка необходимости сохранения данных в Excel
        if save_excel:
            # Вызов метода сохранения в Excel
            self.save_to_excel(data, columns)

        # Импорт данных в базу данных
        success, message = self.import_to_database(df)
        # Возврат результата импорта
        return success, message


# Функция для обратной совместимости
def run_full_cycle(save_excel=False, db_file="certificates.db"):
    # Создание экземпляра импортера
    importer = YandexFormsImporter(db_file)
    # Запуск импорта и возврат результата
    return importer.run_import(save_excel)