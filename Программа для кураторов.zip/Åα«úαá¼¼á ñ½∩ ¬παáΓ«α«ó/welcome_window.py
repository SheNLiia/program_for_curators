# welcome_window.py

# Импорт модуля tkinter под псевдонимом tk
import tkinter as tk
# Импорт модуля ttk из tkinter
from tkinter import ttk
# Импорт класса CuratorWindow из модуля curator_window
from curator_window import CuratorWindow


# Определение класса WelcomeWindow
class WelcomeWindow:
    # Конструктор класса
    def __init__(self):
        # Создание главного окна Tkinter
        self.window = tk.Tk()
        # Установка заголовка окна
        self.window.title("Система справок")

        # Установка размеров окна 500x400 пикселей
        self.window.geometry("500x400")
        # Запрет изменения размеров окна по ширине и высоте
        self.window.resizable(False, False)

        # Вызов метода для центрирования окна на экране
        self._center_window()

        # Вызов метода для создания интерфейса
        self._create_interface()

    # Метод центрирования окна на экране
    def _center_window(self):
        # Получение ширины экрана
        screen_width = self.window.winfo_screenwidth()
        # Получение высоты экрана
        screen_height = self.window.winfo_screenheight()

        # Вычисление координаты X для размещения окна по центру
        x = (screen_width - 500) // 2  # 500 - ширина окна
        # Вычисление координаты Y для размещения окна по центру
        y = (screen_height - 400) // 2  # 400 - высота окна

        # Установка размеров и положения окна
        self.window.geometry(f"500x400+{x}+{y}")

    # Метод создания интерфейса
    def _create_interface(self):
        # Создание главного фрейма с отступами
        main_frame = ttk.Frame(self.window)
        # Размещение главного фрейма с заполнением по обеим осям и отступами
        main_frame.pack(fill='both', expand=True, padx=30, pady=30)

        # Создание метки заголовка с текстом и шрифтом
        title = ttk.Label(main_frame, text="Добро пожаловать!",
                          font=("Arial", 16, "bold"))
        # Размещение метки заголовка с отступами
        title.pack(pady=20)

        # Создание метки подзаголовка с текстом и шрифтом
        subtitle = ttk.Label(main_frame, text="Система автоматизации справок",
                             font=("Arial", 12))
        # Размещение метки подзаголовка с отступами
        subtitle.pack(pady=10)

        # Создание кнопки для открытия системы
        open_btn = ttk.Button(main_frame, text="Открыть систему",
                              command=self._open_system, width=20)
        # Размещение кнопки с отступами
        open_btn.pack(pady=30)

        # Создание разделительной линии
        line = ttk.Separator(main_frame)
        # Размещение разделительной линии с заполнением по X и отступами
        line.pack(fill='x', pady=30)

        # Создание информационной метки с текстом, выравниванием и цветом
        info = ttk.Label(main_frame,
                         text="Система автоматизации подачи справок\nдля КМПО РАНХиГС",
                         justify='center', foreground="gray")
        # Размещение информационной метки
        info.pack()

    # Метод открытия основного окна системы
    def _open_system(self):
        # Закрытие текущего окна
        self.window.destroy()
        # Создание экземпляра окна куратора
        app = CuratorWindow()
        # Запуск окна куратора
        app.run()

    # Метод запуска главного цикла приложения
    def run(self):
        # Запуск главного цикла Tkinter
        self.window.mainloop()