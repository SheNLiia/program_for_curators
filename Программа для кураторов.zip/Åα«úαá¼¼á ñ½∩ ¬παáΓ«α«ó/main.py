# main.py
# Импорт класса стартового окна
from welcome_window import WelcomeWindow

# Проверка запуска как основной программы
if __name__ == "__main__":
    # Создание и запуск стартового окна
    WelcomeWindow().run()