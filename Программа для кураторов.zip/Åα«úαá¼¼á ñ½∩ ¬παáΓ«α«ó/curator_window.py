# curator_window.py

# Импорт модуля tkinter под псевдонимом tk
import tkinter as tk
# Импорт модулей ttk и messagebox из tkinter
from tkinter import ttk, messagebox
# Импорт класса datetime из модуля datetime
from datetime import datetime
# Импорт модуля для открытия веб-браузера
import webbrowser
# Импорт библиотеки pandas под псевдонимом pd
import pandas as pd
# Импорт модуля для работы с JSON
import json
# Импорт модуля для работы с операционной системой
import os
# Импорт модуля для запуска подпроцессов
import subprocess
# Импорт модуля sys для работы с системными параметрами
import sys
# Импорт класса Database из модуля database
from database import Database


# Определение класса CuratorWindow
class CuratorWindow:
    # Конструктор класса
    def __init__(self):
        # Создание главного окна Tkinter
        self.window = tk.Tk()
        # Установка заголовка окна
        self.window.title("Система справок - Для кураторов")
        # Установка размеров окна 1450x800 пикселей
        self.window.geometry("1450x800")
        # Запрет изменения размеров окна по ширине и высоте
        self.window.resizable(False, False)

        # Попытка подключения к базе данных
        try:
            # Создание экземпляра класса Database
            self.db = Database()
        # Обработка исключения FileNotFoundError
        except FileNotFoundError as e:
            # Показ сообщения об ошибке
            messagebox.showerror("Ошибка", f"{e}\nСоздайте базу данных из SQL-файла")
            # Закрытие окна
            self.window.destroy()
            # Выход из конструктора
            return

        # Инициализация списка для хранения выбранных идентификаторов записей
        self.selected_ids = []
        # Инициализация списка для хранения текущих данных
        self.current_data = []

        # Инициализация переменной для хранения текущей колонки сортировки
        self.sort_column = None
        # Инициализация переменной для хранения направления сортировки
        self.sort_reverse = False

        # Вызов метода для центрирования главного окна
        self._center_window(self.window, 1450, 800)

        # Вызов метода для создания интерфейса
        self._create_interface()

        # Вызов метода для загрузки данных
        self._load_data()

        # Установка обработчика закрытия окна
        self.window.protocol("WM_DELETE_WINDOW", self.window.destroy)

    # Метод центрирования окна на экране
    def _center_window(self, window, width, height):
        # Получение ширины экрана
        screen_width = window.winfo_screenwidth()
        # Получение высоты экрана
        screen_height = window.winfo_screenheight()

        # Вычисление координаты X для центрирования
        x = (screen_width - width) // 2
        # Вычисление координаты Y для центрирования
        y = (screen_height - height) // 2

        # Установка размеров и положения окна
        window.geometry(f"{width}x{height}+{x}+{y}")

    # Метод центрирования дочернего окна относительно родительского
    def _center_child_window(self, child_window, parent_window, width, height):
        # Получение координаты X родительского окна
        parent_x = parent_window.winfo_x()
        # Получение координаты Y родительского окна
        parent_y = parent_window.winfo_y()
        # Получение ширины родительского окна
        parent_width = parent_window.winfo_width()
        # Получение высоты родительского окна
        parent_height = parent_window.winfo_height()

        # Вычисление координаты X для дочернего окна
        x = parent_x + (parent_width - width) // 2
        # Вычисление координаты Y для дочернего окна
        y = parent_y + (parent_height - height) // 2

        # Установка размеров и положения дочернего окна
        child_window.geometry(f"{width}x{height}+{x}+{y}")

    # Метод создания интерфейса
    def _create_interface(self):
        # Создание фрейма для фильтров с заголовком и отступами
        filter_frame = ttk.LabelFrame(self.window, text="Фильтры", padding=10)
        # Размещение фрейма фильтров с заполнением по X и отступами
        filter_frame.pack(fill='x', padx=5, pady=5)

        # Создание метки для поля ввода группы
        ttk.Label(filter_frame, text="Группа:").grid(row=0, column=0, padx=5)
        # Создание поля ввода для группы
        self.group_input = ttk.Entry(filter_frame, width=15)
        # Размещение поля ввода группы в сетке
        self.group_input.grid(row=0, column=1, padx=5)
        # Вставка значения по умолчанию в поле ввода группы
        self.group_input.insert(0, "403ИС-22")

        # Создание метки для поля выбора специальности
        ttk.Label(filter_frame, text="Специальность:").grid(row=0, column=2, padx=5)
        # Создание выпадающего списка для специальности
        self.major_input = ttk.Combobox(filter_frame, width=30, state="readonly")
        # Размещение выпадающего списка специальности в сетке
        self.major_input.grid(row=0, column=3, padx=5)

        # Создание метки для поля ввода даты "с"
        ttk.Label(filter_frame, text="Дата с:").grid(row=0, column=4, padx=5)
        # Создание поля ввода для даты "с"
        self.date_from_input = ttk.Entry(filter_frame, width=12)
        # Размещение поля ввода даты "с" в сетке
        self.date_from_input.grid(row=0, column=5, padx=5)
        # Вставка значения по умолчанию в поле ввода даты "с"
        self.date_from_input.insert(0, "01.01.2025")

        # Создание метки для поля ввода даты "по"
        ttk.Label(filter_frame, text="Дата по:").grid(row=0, column=6, padx=5)
        # Создание поля ввода для даты "по"
        self.date_to_input = ttk.Entry(filter_frame, width=12)
        # Размещение поля ввода даты "по" в сетке
        self.date_to_input.grid(row=0, column=7, padx=5)
        # Вставка текущей даты в поле ввода даты "по"
        self.date_to_input.insert(0, datetime.now().strftime('%d.%m.%Y'))

        # Создание метки для поля поиска по ФИО
        ttk.Label(filter_frame, text="Поиск по ФИО:").grid(row=1, column=0, padx=5, pady=10)
        # Создание поля ввода для поиска по ФИО
        self.name_input = ttk.Entry(filter_frame, width=15)
        # Размещение поля ввода поиска по ФИО в сетке
        self.name_input.grid(row=1, column=1, padx=5, pady=10)

        # Создание кнопки для применения фильтров
        ttk.Button(filter_frame, text="Применить фильтры",
                   command=self._apply_filters).grid(row=1, column=2, padx=10, pady=10)

        # Создание кнопки для показа всех студентов
        ttk.Button(filter_frame, text="Показать всех студентов",
                   command=self._show_all).grid(row=1, column=3, padx=5, pady=10)

        # Создание фрейма для таблицы с заголовком и отступами
        table_frame = ttk.LabelFrame(self.window, text="Заявления", padding=10)
        # Размещение фрейма таблицы с заполнением по обеим осям и отступами
        table_frame.pack(fill='both', expand=True, padx=5, pady=5)

        # Создание таблицы с указанными колонками
        self.table = ttk.Treeview(table_frame,
                                  columns=("student", "major", "group", "date", "parent", "period", "status"),
                                  show='headings', height=15, selectmode='extended')

        # Определение колонок с идентификатором, названием и шириной
        columns = [
            ("student", "Студент", 120),
            ("major", "Специальность", 200),
            ("group", "Группа", 80),
            ("date", "Дата подачи", 140),
            ("parent", "Родитель", 120),
            ("period", "Период отсутствия", 120),
            ("status", "Статус", 120)
        ]

        # Настройка заголовков и колонок таблицы
        for col_id, col_name, width in columns:
            # Установка заголовка колонки с командой для сортировки
            self.table.heading(col_id, text=col_name,
                               command=lambda c=col_id: self._sort_table(c))
            # Установка ширины колонки
            self.table.column(col_id, width=width)

        # Создание полосы прокрутки для таблицы
        scrollbar = ttk.Scrollbar(table_frame, command=self.table.yview)
        # Настройка команды прокрутки таблицы
        self.table.configure(yscrollcommand=scrollbar.set)

        # Размещение таблицы слева с заполнением по обеим осям
        self.table.pack(side='left', fill='both', expand=True)
        # Размещение полосы прокрутки справа с заполнением по Y
        scrollbar.pack(side='right', fill='y')

        # Привязка события выбора строки к методу обработки
        self.table.bind('<<TreeviewSelect>>', self._on_select)

        # Создание фрейма для кнопок
        button_frame = ttk.Frame(self.window)
        # Размещение фрейма кнопок с заполнением по X и отступами
        button_frame.pack(fill='x', padx=5, pady=10)

        # Создание кнопки для просмотра деталей заявления
        self.view_button = ttk.Button(button_frame, text="Подробнее о заявлении",
                                      command=self._view_details, state="disabled")
        # Размещение кнопки просмотра деталей слева с отступом
        self.view_button.pack(side='left', padx=5)

        # Создание кнопки для загрузки данных из Яндекс.Форм
        ttk.Button(button_frame, text="Загрузить из Яндекс.Форм",
                   command=self._load_from_yandex).pack(side='left', padx=5)

        # Создание кнопки для отметки как просмотренного
        self.mark_button = ttk.Button(button_frame, text="Отметить просмотренным",
                                      command=self._mark_as_viewed, state="disabled")
        # Размещение кнопки отметки просмотренного слева с отступом
        self.mark_button.pack(side='left', padx=5)

        # Создание кнопки для отметки всех как просмотренных
        ttk.Button(button_frame, text="Отметить все как просмотренные",
                   command=self._mark_all_viewed).pack(side='left', padx=5)

        # Создание кнопки для экспорта в Excel
        ttk.Button(button_frame, text="Экспорт в Excel",
                   command=self._export_to_excel).pack(side='right', padx=5)

        # Создание кнопки для удаления заявления
        self.delete_button = ttk.Button(button_frame, text="Удалить заявление",
                                        command=self._delete_selected, state="disabled")
        # Размещение кнопки удаления слева с отступом
        self.delete_button.pack(side='left', padx=5)

        # Создание кнопки для возврата назад
        ttk.Button(self.window, text="Вернуться назад",
                   command=self._go_back).pack(side='bottom', pady=10)

    # Метод сортировки таблицы по колонке
    def _sort_table(self, column):
        # Проверка, совпадает ли текущая колонка сортировки с выбранной
        if self.sort_column == column:
            # Изменение направления сортировки на противоположное
            self.sort_reverse = not self.sort_reverse
        else:
            # Установка новой колонки сортировки
            self.sort_column = column
            # Сброс направления сортировки
            self.sort_reverse = False

        # Получение всех элементов таблицы с их значениями в выбранной колонке
        items = [(self.table.set(item, column), item)
                 for item in self.table.get_children('')]

        # Попытка сортировки в зависимости от типа данных в колонке
        try:
            # Проверка, является ли колонка датой или периодом
            if column in ['date', 'period']:
                # Для колонки с датой используется специальная функция парсинга
                if column == 'date':
                    items.sort(key=lambda x: self._parse_date_for_sort(x[0]),
                               reverse=self.sort_reverse)
                # Для колонки с периодом используется специальная функция парсинга
                elif column == 'period':
                    items.sort(key=lambda x: self._parse_period_for_sort(x[0]),
                               reverse=self.sort_reverse)
            else:
                # Для остальных колонок используется обычная сортировка по нижнему регистру
                items.sort(key=lambda x: x[0].lower(), reverse=self.sort_reverse)
        except:
            # В случае ошибки используется обычная сортировка по нижнему регистру
            items.sort(key=lambda x: x[0].lower(), reverse=self.sort_reverse)

        # Перемещение элементов таблицы в отсортированном порядке
        for index, (_, item) in enumerate(items):
            self.table.move(item, '', index)

        # Обновление индикаторов сортировки
        self._update_sort_indicators(column)

    # Метод парсинга даты для сортировки
    def _parse_date_for_sort(self, date_str):
        try:
            # Проверка наличия пробела в строке даты (возможно, содержит время)
            if ' ' in date_str:
                # Извлечение только части с датой
                date_part = date_str.split()[0]
            else:
                date_part = date_str

            # Попытка парсинга даты в формате DD.MM.YYYY
            try:
                return datetime.strptime(date_part, '%d.%m.%Y')
            except:
                # Попытка парсинга даты в формате YYYY-MM-DD
                try:
                    return datetime.strptime(date_part, '%Y-%m-%d')
                except:
                    # Возврат минимальной даты в случае ошибки
                    return datetime.min
        except:
            # Возврат минимальной даты в случае исключения
            return datetime.min

    # Метод парсинга периода для сортировки
    def _parse_period_for_sort(self, period_str):
        try:
            # Проверка наличия разделителя ' - ' в строке периода
            if ' - ' in period_str:
                # Извлечение даты начала периода
                start_date = period_str.split(' - ')[0].strip()
                # Парсинг даты начала с помощью метода для дат
                return self._parse_date_for_sort(start_date)
            else:
                # Парсинг всей строки как даты
                return self._parse_date_for_sort(period_str)
        except:
            # Возврат минимальной даты в случае исключения
            return datetime.min

    # Метод обновления индикаторов сортировки
    def _update_sort_indicators(self, column):
        # Перебор всех колонок таблицы
        for col in self.table['columns']:
            # Получение текущего текста заголовка колонки
            current_text = self.table.heading(col)['text']
            # Удаление стрелочек сортировки, если они присутствуют
            if current_text.endswith(' ↑') or current_text.endswith(' ↓'):
                current_text = current_text[:-2]
            # Установка очищенного текста заголовка
            self.table.heading(col, text=current_text)

        # Получение текущего текста заголовка выбранной колонки
        current_text = self.table.heading(column)['text']
        # Выбор стрелочки в зависимости от направления сортировки
        arrow = ' ↓' if self.sort_reverse else ' ↑'
        # Установка нового текста заголовка с стрелочкой
        self.table.heading(column, text=current_text + arrow)

    # Метод сброса индикаторов сортировки
    def _reset_sort_indicators(self):
        # Перебор всех колонок таблицы
        for col in self.table['columns']:
            # Получение текущего текста заголовка колонки
            current_text = self.table.heading(col)['text']
            # Удаление стрелочек сортировки, если они присутствуют
            if current_text.endswith(' ↑') or current_text.endswith(' ↓'):
                current_text = current_text[:-2]
            # Установка очищенного текста заголовка
            self.table.heading(col, text=current_text)

        # Сброс переменной колонки сортировки
        self.sort_column = None
        # Сброс переменной направления сортировки
        self.sort_reverse = False

    # Метод загрузки данных в таблицу
    def _load_data(self):
        # Очистка всех элементов таблицы
        for item in self.table.get_children():
            self.table.delete(item)

        # Получение данных из базы данных без фильтров
        data = self.db.get_certificates_with_filters({})

        # Сохранение текущих данных
        self.current_data = data

        # Добавление данных в таблицу
        for item in data:
            self.table.insert('', 'end', values=(
                item['student'],
                item['major'],
                item['group'],
                item['created_at'],
                item['parent'],
                item['period'],
                item['status']
            ), tags=(item['certificate_id'],))

        # Получение списка всех специальностей из базы данных
        majors = self.db.get_all_majors()
        # Установка значений для выпадающего списка специальностей
        self.major_input['values'] = majors
        # Установка значения по умолчанию для выпадающего списка
        if majors:
            self.major_input.set("Все")

        # Сброс индикаторов сортировки
        self._reset_sort_indicators()

    # Метод применения фильтров
    def _apply_filters(self):
        # Создание пустого словаря для фильтров
        filters = {}

        # Получение значения фильтра группы
        group = self.group_input.get().strip()
        # Добавление фильтра группы, если значение не пустое
        if group:
            filters['group'] = group

        # Получение значения фильтра специальности
        major = self.major_input.get().strip()
        # Добавление фильтра специальности, если значение не пустое и не равно "Все"
        if major and major != "Все":
            filters['major'] = major

        # Получение значения фильтра даты "с"
        date_from = self.date_from_input.get().strip()
        # Добавление фильтра даты "с", если значение не пустое
        if date_from:
            filters['date_from'] = self._format_date(date_from)

        # Получение значения фильтра даты "по"
        date_to = self.date_to_input.get().strip()
        # Добавление фильтра даты "по", если значение не пустое
        if date_to:
            filters['date_to'] = self._format_date(date_to)

        # Получение значения фильтра поиска по ФИО
        name = self.name_input.get().strip()
        # Добавление фильтра поиска по ФИО, если значение не пустое
        if name:
            filters['fio'] = name

        # Обновление таблицы с примененными фильтрами
        self._update_table(filters)

    # Метод форматирования даты из DD.MM.YYYY в YYYY-MM-DD
    def _format_date(self, date_str):
        try:
            # Разделение строки даты по точке
            parts = date_str.split('.')
            # Проверка, что дата состоит из трех частей
            if len(parts) == 3:
                day, month, year = parts
                # Формирование даты в формате YYYY-MM-DD
                return f"{year}-{month}-{day}"
        except:
            pass
        # Возврат исходной строки в случае ошибки
        return date_str

    # Метод обновления таблицы с данными
    def _update_table(self, filters=None):
        # Очистка всех элементов таблицы
        for item in self.table.get_children():
            self.table.delete(item)

        # Получение данных из базы данных с примененными фильтрами
        data = self.db.get_certificates_with_filters(filters)
        # Сохранение текущих данных
        self.current_data = data

        # Добавление данных в таблицу
        for item in data:
            self.table.insert('', 'end', values=(
                item['student'],
                item['major'],
                item['group'],
                item['created_at'],
                item['parent'],
                item['period'],
                item['status']
            ), tags=(item['certificate_id'],))

        # Получение количества найденных записей
        count = len(data)
        # Обновление заголовка окна с количеством записей
        self.window.title(f"Система справок - Для кураторов (Найдено: {count})")

        # Сброс индикаторов сортировки
        self._reset_sort_indicators()

    # Метод показа всех записей (сброс фильтров)
    def _show_all(self):
        # Очистка поля ввода группы
        self.group_input.delete(0, tk.END)
        # Вставка пустой строки в поле ввода группы
        self.group_input.insert(0, "")

        # Установка значения "Все" в выпадающем списке специальностей
        self.major_input.set("Все")

        # Очистка поля ввода даты "с"
        self.date_from_input.delete(0, tk.END)
        # Вставка пустой строки в поле ввода даты "с"
        self.date_from_input.insert(0, "")

        # Очистка поля ввода даты "по"
        self.date_to_input.delete(0, tk.END)
        # Вставка пустой строки в поле ввода даты "по"
        self.date_to_input.insert(0, "")

        # Очистка поля ввода поиска по ФИО
        self.name_input.delete(0, tk.END)

        # Обновление таблицы без фильтров
        self._update_table({})

    # Метод обработки выбора строк в таблице
    def _on_select(self, event):
        # Получение выбранных элементов таблицы
        selection = self.table.selection()

        # Проверка, есть ли выбранные элементы
        if selection:
            # Очистка списка выбранных идентификаторов
            self.selected_ids = []
            # Перебор выбранных элементов
            for item in selection:
                # Получение тега (идентификатора) элемента
                tag = self.table.item(item, "tags")[0]
                # Добавление идентификатора в список выбранных
                self.selected_ids.append(int(tag))

            # Определение, можно ли просматривать детали (только одна запись)
            can_view = (len(selection) == 1)
            # Включение или отключение кнопки просмотра деталей
            self.view_button.config(state="normal" if can_view else "disabled")
            # Включение кнопки отметки как просмотренного
            self.mark_button.config(state="normal")
            # Включение кнопки удаления
            self.delete_button.config(state="normal")
        else:
            # Очистка списка выбранных идентификаторов
            self.selected_ids = []
            # Отключение кнопки просмотра деталей
            self.view_button.config(state="disabled")
            # Отключение кнопки отметки как просмотренного
            self.mark_button.config(state="disabled")
            # Отключение кнопки удаления
            self.delete_button.config(state="disabled")

    # Метод просмотра детальной информации о выбранной записи
    def _view_details(self):
        # Проверка, выбраны ли записи
        if not self.selected_ids:
            # Показ предупреждения, если ничего не выбрано
            messagebox.showwarning("Внимание", "Выберите заявление для просмотра")
            return

        # Получение идентификатора первой выбранной записи
        cert_id = self.selected_ids[0]
        # Получение детальной информации о записи из базы данных
        data = self.db.get_certificate_details(cert_id)

        # Проверка, получены ли данные
        if data:
            # Создание дочернего окна для отображения деталей
            info_window = tk.Toplevel(self.window)
            # Установка заголовка окна с идентификатором записи
            info_window.title(f"Заявление #{cert_id}")
            # Установка размеров окна
            info_window.geometry("600x400")
            # Запрет изменения размеров окна
            info_window.resizable(False, False)

            # Центрирование дочернего окна относительно главного
            self._center_child_window(info_window, self.window, 600, 400)

            # Получение значений данных или установка "не указано" для пустых значений
            student = data['student'] if data['student'] else "не указано"
            group = data['group'] if data['group'] else "не указано"
            major = data['major'] if data['major'] else "не указано"
            created_at = data['created_at'] if data['created_at'] else "не указано"
            absence_start = data['absence_start'] if data['absence_start'] else "не указано"
            absence_end = data['absence_end'] if data['absence_end'] else "не указано"
            parent = data['parent'] if data['parent'] else "не указано"

            # Получение телефона родителя или установка "не указано"
            parent_phone = data.get('parent_phone', 'не указано')
            if parent_phone is None or parent_phone == '':
                parent_phone = "не указано"

            # Получение email родителя или установка "не указано"
            parent_email = data.get('parent_email', 'не указано')
            if parent_email is None or parent_email == '':
                parent_email = "не указано"

            status = data['status'] if data['status'] else "не указано"

            # Формирование текста с информацией
            info_text = f"""
            Студент: {student}
            Группа: {group}
            Специальность: {major}

            Дата подачи: {created_at}
            Период отсутствия: {absence_start} - {absence_end}

            Родитель: {parent}
            Телефон: {parent_phone}
            Email: {parent_email}

            Статус: {status}
            """

            # Создание метки с текстом информации
            tk.Label(info_window, text=info_text.strip(),
                     justify=tk.LEFT, font=("Arial", 10)).pack(padx=20, pady=20)

            # Проверка наличия URL файла
            if data.get('file_url'):
                # Создание кнопки для скачивания файла
                ttk.Button(info_window, text="Скачать файл",
                           command=lambda: self._download_and_close(
                               info_window, data['file_url'], data.get('file_name', 'файл')
                           )).pack(pady=10)

            # Создание кнопки для закрытия окна
            ttk.Button(info_window, text="Закрыть",
                       command=info_window.destroy).pack(pady=10)

    # Метод скачивания файла и закрытия окна
    def _download_and_close(self, window, file_data, filename):
        # Закрытие окна с деталями
        window.destroy()
        # Обработка скачивания файла
        self._process_download(file_data, filename)

    # Метод обработки скачивания файла
    def _process_download(self, file_data, filename):
        # Проверка наличия данных о файле и имени файла
        if not file_data or not filename:
            # Показ сообщения об ошибке
            messagebox.showerror("Ошибка", "Нет информации о файле")
            return

        # Попытка разобрать данные о файле
        try:
            # Проверка, является ли file_data строкой
            if isinstance(file_data, str):
                # Проверка, является ли строка списком в квадратных скобках
                if file_data.startswith('[') and file_data.endswith(']'):
                    # Удаление квадратных скобок
                    file_data = file_data[1:-1]

                # Проверка, является ли строка JSON объектом
                if file_data.startswith('{') and file_data.endswith('}'):
                    try:
                        # Попытка загрузки JSON
                        file_info = json.loads(file_data)
                    except:
                        # Замена одинарных кавычек на двойные и повторная попытка
                        file_data = file_data.replace("'", '"')
                        file_info = json.loads(file_data)

                    # Извлечение URL и имени файла из JSON
                    url = file_info.get('path') or file_info.get('url') or file_info.get('href')
                    real_filename = file_info.get('name') or filename
                else:
                    # Использование строки как URL
                    url = file_data
                    real_filename = filename
            else:
                # Использование file_data как словаря
                file_info = file_data
                # Извлечение URL и имени файла из словаря
                url = file_info.get('path') or file_info.get('url') or file_info.get('href')
                real_filename = file_info.get('name') or filename

            # Проверка, начинается ли URL с http
            if url and not url.startswith('http'):
                # Проверка наличия определенных подстрок в URL
                if 'yandex.ru/cloud/files' in url or 'forms.yandex.ru/cloud/files' in url:
                    pass
                else:
                    # Добавление префикса https:// к URL
                    url = f"https://forms.yandex.ru{url}" if url.startswith('/') else f"https://{url}"

            # Открытие URL в веб-браузере
            webbrowser.open(url)
            # Показ информационного сообщения
            messagebox.showinfo("Скачивание", f"Файл '{real_filename}' открывается в браузере")

        except Exception as e:
            # Показ сообщения об ошибке при обработке ссылки
            messagebox.showerror("Ошибка", f"Не удалось обработать ссылку: {e}")

    # Метод загрузки данных из Яндекс.Форм
    def _load_from_yandex(self):
        try:
            # Импорт функции run_full_cycle из модуля yandex_import
            from yandex_import import run_full_cycle

            # Показ информационного сообщения о начале загрузки
            messagebox.showinfo("Загрузка", "Начинаем загрузку данных...")
            # Запуск импорта данных
            success, msg = run_full_cycle()

            # Проверка успешности импорта
            if success:
                # Показ сообщения об успехе
                messagebox.showinfo("Успех", f"Данные успешно сохранены локально.\n{msg}")
                # Обновление данных в таблице
                self._load_data()
            else:
                # Показ сообщения об ошибке
                messagebox.showerror("Ошибка", msg)
        except Exception as e:
            # Показ сообщения об ошибке при импорте
            messagebox.showerror("Ошибка", f"Не удалось загрузить данные: {e}")

    # Метод отметки выбранной записи как просмотренной
    def _mark_as_viewed(self):
        # Проверка, выбраны ли записи
        if not self.selected_ids:
            # Показ предупреждения, если ничего не выбрано
            messagebox.showwarning("Внимание", "Выберите заявление")
            return

        # Обновление статуса записи в базе данных
        if self.db.update_certificate_status(self.selected_ids[0], "Просмотрено"):
            # Показ сообщения об успехе
            messagebox.showinfo("Успех", "Заявление отмечено как просмотренное")
            # Обновление данных в таблице
            self._load_data()

    # Метод отметки всех записей как просмотренных
    def _mark_all_viewed(self):
        # Запрос подтверждения у пользователя
        if messagebox.askyesno("Подтверждение", "Отметить все заявления как просмотренные?"):
            # Вызов метода базы данных для отметки всех как просмотренных
            if self.db.mark_all_as_viewed():
                # Показ сообщения об успехе
                messagebox.showinfo("Успех", "Все заявления отмечены как просмотренные")
                # Обновление данных в таблице
                self._load_data()

    # Метод удаления выбранных записей
    def _delete_selected(self):
        # Проверка, выбраны ли записи
        if not self.selected_ids:
            # Показ предупреждения, если ничего не выбрано
            messagebox.showwarning("Внимание", "Выберите заявления для удаления")
            return

        # Подсчет количества выбранных записей
        count = len(self.selected_ids)

        # Запрос подтверждения у пользователя
        if messagebox.askyesno("Подтверждение", f"Удалить {count} заявлений?"):
            # Инициализация флага успешности
            success = True
            # Перебор выбранных идентификаторов
            for cert_id in self.selected_ids:
                # Удаление записи из базы данных
                if not self.db.delete_certificate(cert_id):
                    success = False

            # Проверка успешности удаления всех записей
            if success:
                # Показ сообщения об успехе
                messagebox.showinfo("Успех", f"Удалено {count} заявлений")
                # Обновление данных в таблице
                self._load_data()
            else:
                # Показ предупреждения о частичном удалении
                messagebox.showwarning("Частично", "Не все заявления удалены")

    # Метод экспорта данных в Excel
    def _export_to_excel(self):
        try:
            # Проверка наличия данных для экспорта
            if not self.current_data:
                # Показ предупреждения об отсутствии данных
                messagebox.showwarning("Нет данных", "Нет данных для экспорта")
                return

            # Создание списка для данных Excel
            data_for_excel = []

            # Перебор текущих данных
            for item in self.current_data:
                # Добавление словаря с данными в список
                data_for_excel.append({
                    'ID': item['certificate_id'],
                    'Студент': item['student'],
                    'Специальность': item['major'],
                    'Группа': item['group'],
                    'Дата подачи': item['created_at'],
                    'Родитель': item['parent'],
                    'Период': item['period'],
                    'Статус': item['status']
                })

            # Создание DataFrame из списка данных
            df = pd.DataFrame(data_for_excel)

            # Формирование имени файла с текущей датой и временем
            filename = f"экспорт_{datetime.now().strftime('%Y%m%d_%H%M%S')}.xlsx"
            # Сохранение DataFrame в Excel файл
            df.to_excel(filename, index=False, engine='openpyxl')

            # Получение количества экспортированных записей
            count = len(self.current_data)
            # Показ информационного сообщения об экспорте
            messagebox.showinfo("Экспорт", f"Экспортировано {count} записей\nФайл сохранен как: {filename}")

            # Запрос пользователя об открытии файла
            if messagebox.askyesno("Открыть файл", "Хотите открыть экспортированный файл?"):
                try:
                    # Проверка операционной системы
                    if os.name == 'nt':
                        # Открытие файла в Windows
                        os.startfile(filename)
                    elif os.name == 'posix':
                        # Проверка, является ли система macOS
                        if sys.platform == 'darwin':
                            # Открытие файла в macOS
                            subprocess.call(['open', filename])
                        else:
                            # Открытие файла в Linux
                            subprocess.call(['xdg-open', filename])
                except Exception as e:
                    # Вывод ошибки в консоль
                    print(f"Ошибка при открытии файла: {e}")
                    # Показ информационного сообщения о местоположении файла
                    messagebox.showinfo("Информация", f"Файл сохранен в текущей папке:\n{os.path.abspath(filename)}")

        except Exception as e:
            # Показ сообщения об ошибке при экспорте
            messagebox.showerror("Ошибка", f"Не удалось экспортировать: {e}")

    # Метод возврата к стартовому окну
    def _go_back(self):
        # Закрытие текущего окна
        self.window.destroy()
        # Импорт класса WelcomeWindow из модуля welcome_window
        from welcome_window import WelcomeWindow
        # Создание экземпляра WelcomeWindow и его запуск
        WelcomeWindow().run()

    # Метод запуска главного цикла окна
    def run(self):
        # Запуск главного цикла Tkinter
        self.window.mainloop()